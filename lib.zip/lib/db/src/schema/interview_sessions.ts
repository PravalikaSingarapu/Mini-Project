import { pgTable, text, serial, integer, real, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const interviewSessionsTable = pgTable("interview_sessions", {
  id: serial("id").primaryKey(),
  roleId: text("role_id").notNull(),
  roleName: text("role_name").notNull(),
  status: text("status").notNull().default("in_progress"),
  currentQuestionIndex: integer("current_question_index").notNull().default(0),
  totalQuestions: integer("total_questions").notNull().default(10),
  resumeText: text("resume_text"),
  questions: jsonb("questions"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertInterviewSessionSchema = createInsertSchema(interviewSessionsTable).omit({ id: true, createdAt: true });
export type InsertInterviewSession = z.infer<typeof insertInterviewSessionSchema>;
export type InterviewSession = typeof interviewSessionsTable.$inferSelect;

export const interviewAnswersTable = pgTable("interview_answers", {
  id: serial("id").primaryKey(),
  sessionId: integer("session_id").notNull(),
  questionIndex: integer("question_index").notNull(),
  question: text("question").notNull(),
  transcribedText: text("transcribed_text").notNull(),
  score: real("score").notNull().default(0),
  feedback: text("feedback").notNull().default(""),
  suggestions: text("suggestions").notNull().default(""),
  keywordsFound: jsonb("keywords_found").notNull().default([]),
  keywordsMissed: jsonb("keywords_missed").notNull().default([]),
  emotion: text("emotion").notNull().default("Neutral"),
  speakingQuality: text("speaking_quality").notNull().default("Average"),
  timeTakenSeconds: integer("time_taken_seconds").notNull().default(0),
  completionStatus: text("completion_status").notNull().default("completed"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertInterviewAnswerSchema = createInsertSchema(interviewAnswersTable).omit({ id: true, createdAt: true });
export type InsertInterviewAnswer = z.infer<typeof insertInterviewAnswerSchema>;
export type InterviewAnswer = typeof interviewAnswersTable.$inferSelect;
