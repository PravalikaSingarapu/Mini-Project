import { useState } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { Mic, FileText, BrainCircuit, Loader2 } from "lucide-react";
import { useListJobRoles, useCreateInterviewSession } from "@workspace/api-client-react";
import { cn } from "@/lib/utils";

export default function Home() {
  const [, setLocation] = useLocation();
  const [selectedRole, setSelectedRole] = useState<string>("");
  const [resumeText, setResumeText] = useState("");

  const { data: roles = [], isLoading: isLoadingRoles } = useListJobRoles();
  const createSession = useCreateInterviewSession({
    mutation: {
      onSuccess: (data) => {
        setLocation(`/interview/${data.id}`);
      }
    }
  });

  const handleStart = () => {
    if (!selectedRole) return;
    createSession.mutate({ data: { roleId: selectedRole, resumeText } });
  };

  return (
    <div className="min-h-screen relative overflow-hidden flex flex-col items-center justify-center p-4 sm:p-8">
      {/* Background Image & Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src={`${import.meta.env.BASE_URL}images/hero-bg.png`}
          alt="Hero abstract background" 
          className="w-full h-full object-cover opacity-60"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/80 via-background/95 to-background"></div>
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        className="relative z-10 w-full max-w-3xl flex flex-col items-center"
      >
        <div className="w-16 h-16 rounded-2xl bg-primary/20 flex items-center justify-center mb-6 shadow-lg shadow-primary/20 border border-primary/30">
          <BrainCircuit className="w-8 h-8 text-primary" />
        </div>
        
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-display font-bold text-center text-transparent bg-clip-text bg-gradient-to-r from-white to-white/60 mb-4">
          AI Voice Interview Prep
        </h1>
        <p className="text-lg text-muted-foreground text-center max-w-xl mb-12">
          Practice technical interviews with our AI. Speak your answers naturally, get real-time feedback, and improve your confidence.
        </p>

        <div className="w-full bg-card/80 backdrop-blur-xl border border-border/50 rounded-3xl p-6 sm:p-8 shadow-2xl">
          <div className="space-y-8">
            
            {/* Role Selection */}
            <div className="space-y-4">
              <label className="text-sm font-semibold text-foreground flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-primary text-xs">1</div>
                Select Target Role
              </label>
              
              {isLoadingRoles ? (
                <div className="h-32 flex items-center justify-center bg-background/50 rounded-xl border border-border">
                  <Loader2 className="w-6 h-6 animate-spin text-primary" />
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                  {roles.map((role) => (
                    <button
                      key={role.id}
                      onClick={() => setSelectedRole(role.id)}
                      className={cn(
                        "p-4 rounded-xl border text-left transition-all duration-200 hover:-translate-y-0.5",
                        selectedRole === role.id 
                          ? "bg-primary/10 border-primary ring-1 ring-primary shadow-lg shadow-primary/10" 
                          : "bg-background border-border hover:border-primary/50"
                      )}
                    >
                      <h3 className="font-semibold text-foreground">{role.name}</h3>
                      <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{role.description}</p>
                    </button>
                  ))}
                  {roles.length === 0 && (
                    <div className="col-span-full p-4 text-center text-muted-foreground">
                      No roles available at the moment.
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Resume Upload (Optional) */}
            <div className="space-y-4">
              <label className="text-sm font-semibold text-foreground flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-primary text-xs">2</div>
                Paste Resume (Optional)
                <span className="text-xs font-normal text-muted-foreground ml-auto">For custom questions</span>
              </label>
              
              <div className="relative">
                <FileText className="absolute left-4 top-4 w-5 h-5 text-muted-foreground" />
                <textarea
                  value={resumeText}
                  onChange={(e) => setResumeText(e.target.value)}
                  placeholder="Paste your resume content here..."
                  className="w-full h-32 bg-background border border-border rounded-xl pl-12 pr-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all resize-none"
                />
              </div>
            </div>

            {/* Submit Action */}
            <div className="pt-4 border-t border-border/50 flex flex-col sm:flex-row items-center justify-between gap-4">
              <p className="text-sm text-muted-foreground flex items-center gap-2">
                <Mic className="w-4 h-4" /> Ensure microphone permissions are enabled
              </p>
              <button
                onClick={handleStart}
                disabled={!selectedRole || createSession.isPending}
                className="w-full sm:w-auto px-8 py-3.5 rounded-xl font-bold text-primary-foreground bg-gradient-to-r from-primary to-primary/80 shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/40 hover:-translate-y-0.5 transition-all disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none flex items-center justify-center gap-2"
              >
                {createSession.isPending ? (
                  <><Loader2 className="w-5 h-5 animate-spin" /> Starting...</>
                ) : (
                  "Start Interview"
                )}
              </button>
            </div>

          </div>
        </div>
      </motion.div>
    </div>
  );
}
