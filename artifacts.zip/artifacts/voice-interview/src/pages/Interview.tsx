import { useState, useEffect } from "react";
import { useLocation, useParams } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { useQueryClient } from "@tanstack/react-query";
import { 
  useGetInterviewSession, 
  useGetNextQuestion, 
  useSubmitAnswer,
  getGetNextQuestionQueryKey,
  getGetInterviewSessionQueryKey
} from "@workspace/api-client-react";
import { MicButton } from "@/components/MicButton";
import { TimerRing } from "@/components/TimerRing";
import { FeedbackCard } from "@/components/FeedbackCard";
import { useSpeechRecognition } from "@/hooks/use-speech-recognition";
import { Loader2, AlertCircle, BrainCircuit } from "lucide-react";
import { cn } from "@/lib/utils";

type InterviewState = "WAITING" | "RECORDING" | "ANALYZING" | "FEEDBACK";

export default function Interview() {
  const { id } = useParams();
  const sessionId = parseInt(id || "0", 10);
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();

  const [interviewState, setInterviewState] = useState<InterviewState>("WAITING");
  const [timeLeft, setTimeLeft] = useState(60);
  
  const { 
    isRecording, 
    transcript, 
    startRecording, 
    stopRecording, 
    setTranscript,
    isSupported 
  } = useSpeechRecognition();

  // Queries
  const { data: session, isLoading: isLoadingSession } = useGetInterviewSession(sessionId);
  const { data: question, isLoading: isLoadingQuestion, isError: isQuestionError } = useGetNextQuestion(sessionId, {
    query: {
      retry: false, // Don't retry 404s
    }
  });

  const submitMutation = useSubmitAnswer({
    mutation: {
      onSuccess: () => {
        setInterviewState("FEEDBACK");
      },
      onError: (err) => {
        console.error("Submission failed", err);
        // Fallback state if API fails
        setInterviewState("FEEDBACK");
      }
    }
  });

  // Handle auto-navigation if session is complete or no more questions
  useEffect(() => {
    if (session?.status === "completed" || isQuestionError) {
      setLocation(`/report/${sessionId}`);
    }
  }, [session, isQuestionError, sessionId, setLocation]);

  // Timer logic
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (interviewState === "RECORDING" && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (interviewState === "RECORDING" && timeLeft === 0) {
      handleCompleteAnswer();
    }
    return () => clearInterval(interval);
  }, [interviewState, timeLeft]);

  // Prepare when a new question loads
  useEffect(() => {
    if (question && interviewState === "WAITING") {
      setTimeLeft(question.timeLimitSeconds || 60);
      setTranscript("");
    }
  }, [question, interviewState, setTranscript]);

  const handleToggleRecording = () => {
    if (interviewState === "WAITING") {
      setInterviewState("RECORDING");
      startRecording();
    } else if (interviewState === "RECORDING") {
      handleCompleteAnswer();
    }
  };

  const handleCompleteAnswer = () => {
    stopRecording();
    setInterviewState("ANALYZING");
    
    // Submit to API
    if (question) {
      const timeTaken = (question.timeLimitSeconds || 60) - timeLeft;
      submitMutation.mutate({
        id: sessionId,
        data: {
          questionIndex: question.questionIndex,
          question: question.question,
          transcribedText: transcript || "(No audio detected)",
          timeTakenSeconds: timeTaken === 0 ? 1 : timeTaken
        }
      });
    }
  };

  const handleNextQuestion = () => {
    setInterviewState("WAITING");
    // Invalidate caches to trigger fetch of next question
    queryClient.invalidateQueries({ queryKey: getGetNextQuestionQueryKey(sessionId) });
    queryClient.invalidateQueries({ queryKey: getGetInterviewSessionQueryKey(sessionId) });
  };

  if (isLoadingSession || isLoadingQuestion) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-10 h-10 animate-spin text-primary" />
      </div>
    );
  }

  if (!question || !session) return null;

  const isLastQuestion = question.questionIndex >= question.totalQuestions;

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="flex items-center justify-between px-6 py-4 border-b border-border bg-card/50 backdrop-blur-md sticky top-0 z-50">
        <div className="flex items-center gap-4">
          <div className="px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-primary text-sm font-medium">
            {session.roleName}
          </div>
          <span className="text-muted-foreground text-sm font-medium">
            Question {question.questionIndex} <span className="opacity-50">/ {question.totalQuestions}</span>
          </span>
        </div>
        {/* Progress Bar overall */}
        <div className="w-32 h-2 rounded-full bg-background border border-border overflow-hidden hidden sm:block">
          <div 
            className="h-full bg-primary transition-all duration-500" 
            style={{ width: `${(question.questionIndex / question.totalQuestions) * 100}%` }} 
          />
        </div>
      </header>

      <main className="flex-1 flex flex-col items-center justify-center p-6 sm:p-8 max-w-5xl mx-auto w-full relative">
        
        {!isSupported && (
          <div className="absolute top-4 left-4 right-4 bg-destructive/10 border border-destructive/20 text-destructive px-4 py-3 rounded-xl flex items-center gap-3">
            <AlertCircle className="w-5 h-5 shrink-0" />
            <p className="text-sm font-medium">Your browser does not support the Web Speech API. Audio transcription may not work.</p>
          </div>
        )}

        <AnimatePresence mode="wait">
          {/* Question & Recording State */}
          {(interviewState === "WAITING" || interviewState === "RECORDING") && (
            <motion.div 
              key="question"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="w-full flex flex-col items-center"
            >
              <div className="text-center mb-12">
                <h2 className="text-sm font-semibold text-accent uppercase tracking-widest mb-4">
                  {question.topic}
                </h2>
                <h1 className="text-3xl md:text-4xl lg:text-5xl font-display font-bold text-foreground leading-tight max-w-3xl">
                  {question.question}
                </h1>
              </div>

              <div className="flex flex-col md:flex-row items-center justify-center gap-12 md:gap-24 mb-12 w-full">
                <TimerRing 
                  progress={timeLeft / (question.timeLimitSeconds || 60)} 
                  timeLeft={timeLeft} 
                  totalTime={question.timeLimitSeconds || 60} 
                />
                <MicButton 
                  isRecording={isRecording} 
                  onClick={handleToggleRecording} 
                />
              </div>

              <div className="w-full max-w-2xl bg-card rounded-2xl border border-border p-6 shadow-xl min-h-[160px] relative overflow-hidden flex flex-col">
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-primary/20 to-transparent"></div>
                <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-widest mb-3">Live Transcript</h3>
                <p className={cn(
                  "flex-1 text-lg leading-relaxed transition-colors",
                  transcript ? "text-foreground" : "text-muted-foreground italic"
                )}>
                  {transcript || (interviewState === "RECORDING" ? "Listening..." : "Click the microphone to start answering.")}
                </p>
                {interviewState === "RECORDING" && (
                  <div className="mt-4 flex justify-end">
                    <button 
                      onClick={handleCompleteAnswer}
                      className="text-sm font-semibold text-primary hover:text-primary/80 transition-colors"
                    >
                      Finish Answering →
                    </button>
                  </div>
                )}
              </div>
            </motion.div>
          )}

          {/* Analyzing State */}
          {interviewState === "ANALYZING" && (
            <motion.div 
              key="analyzing"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.05 }}
              className="flex flex-col items-center justify-center py-20"
            >
              <div className="relative w-24 h-24 flex items-center justify-center mb-8">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                  className="absolute inset-0 rounded-full border-4 border-primary/20 border-t-primary"
                />
                <BrainCircuit className="w-8 h-8 text-primary animate-pulse" />
              </div>
              <h2 className="text-2xl font-display font-bold text-foreground mb-2">Analyzing your answer</h2>
              <p className="text-muted-foreground">Evaluating clarity, keywords, and confidence...</p>
            </motion.div>
          )}

          {/* Feedback State */}
          {interviewState === "FEEDBACK" && submitMutation.data && (
            <motion.div key="feedback" className="w-full">
              <FeedbackCard 
                analysis={submitMutation.data} 
                onNext={handleNextQuestion}
                isLastQuestion={isLastQuestion}
              />
            </motion.div>
          )}

          {/* Error Fallback */}
          {interviewState === "FEEDBACK" && !submitMutation.data && (
            <motion.div key="error" className="text-center p-8 bg-card border border-border rounded-2xl">
              <AlertCircle className="w-12 h-12 text-destructive mx-auto mb-4" />
              <h2 className="text-xl font-bold mb-2">Analysis Failed</h2>
              <p className="text-muted-foreground mb-6">We couldn't process that answer. Don't worry, you can continue.</p>
              <button
                onClick={handleNextQuestion}
                className="px-6 py-2 bg-primary text-primary-foreground rounded-lg"
              >
                Proceed
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
