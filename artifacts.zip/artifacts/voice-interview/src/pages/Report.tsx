import { useLocation, useParams } from "wouter";
import { motion } from "framer-motion";
import { useGetInterviewReport } from "@workspace/api-client-react";
import { 
  Trophy, 
  Target, 
  TrendingUp, 
  MessageSquare,
  ChevronRight,
  ArrowRight,
  Loader2
} from "lucide-react";
import { cn } from "@/lib/utils";

export default function Report() {
  const { id } = useParams();
  const sessionId = parseInt(id || "0", 10);
  const [, setLocation] = useLocation();

  const { data: report, isLoading } = useGetInterviewReport(sessionId);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-10 h-10 animate-spin text-primary" />
      </div>
    );
  }

  if (!report) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-background p-6 text-center">
        <h2 className="text-2xl font-bold text-foreground mb-2">Report Not Found</h2>
        <p className="text-muted-foreground mb-6">We couldn't find the interview data.</p>
        <button 
          onClick={() => setLocation("/")}
          className="px-6 py-3 rounded-xl bg-primary text-primary-foreground font-semibold"
        >
          Return Home
        </button>
      </div>
    );
  }

  // Calculate score color class
  const getScoreColor = (score: number) => {
    if (score >= 8) return "text-success bg-success/10 border-success/20";
    if (score >= 6) return "text-warning bg-warning/10 border-warning/20";
    return "text-destructive bg-destructive/10 border-destructive/20";
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Hero Header */}
      <div className="bg-card border-b border-border pt-16 pb-12 px-6 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent pointer-events-none"></div>
        <div className="max-w-5xl mx-auto relative z-10 flex flex-col md:flex-row items-center md:items-start justify-between gap-8">
          <div>
            <div className="px-3 py-1 rounded-full bg-accent/10 border border-accent/20 text-accent text-xs font-semibold uppercase tracking-wider inline-flex mb-4">
              Interview Complete
            </div>
            <h1 className="text-4xl md:text-5xl font-display font-bold text-foreground mb-4">
              Performance Report
            </h1>
            <p className="text-lg text-muted-foreground">
              Role: <strong className="text-foreground">{report.roleName}</strong>
            </p>
          </div>

          <div className="flex items-center gap-6">
            <div className="text-center">
              <p className="text-sm font-medium text-muted-foreground mb-1">Questions</p>
              <p className="text-3xl font-bold text-foreground">{report.answeredQuestions}<span className="text-muted-foreground text-xl">/{report.totalQuestions}</span></p>
            </div>
            <div className="w-px h-12 bg-border"></div>
            <div className="text-center">
              <p className="text-sm font-medium text-muted-foreground mb-1">Average Score</p>
              <div className={cn("px-4 py-1.5 rounded-xl border flex items-center justify-center", getScoreColor(report.averageScore))}>
                <span className="text-3xl font-bold">{report.averageScore.toFixed(1)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <main className="max-w-5xl mx-auto p-6 mt-8 space-y-8">
        
        {/* High Level Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="bg-card rounded-2xl p-6 border border-border shadow-lg">
            <div className="w-10 h-10 rounded-lg bg-success/10 flex items-center justify-center mb-4">
              <Trophy className="w-5 h-5 text-success" />
            </div>
            <h3 className="text-sm font-medium text-muted-foreground mb-2">Strong Topics</h3>
            <div className="flex flex-wrap gap-2">
              {report.strongTopics.map((t, i) => (
                <span key={i} className="px-2 py-1 rounded bg-background border border-border text-xs font-medium">{t}</span>
              ))}
              {report.strongTopics.length === 0 && <span className="text-muted-foreground text-sm">None identified</span>}
            </div>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="bg-card rounded-2xl p-6 border border-border shadow-lg">
            <div className="w-10 h-10 rounded-lg bg-destructive/10 flex items-center justify-center mb-4">
              <Target className="w-5 h-5 text-destructive" />
            </div>
            <h3 className="text-sm font-medium text-muted-foreground mb-2">Areas to Improve</h3>
            <div className="flex flex-wrap gap-2">
              {report.weakTopics.map((t, i) => (
                <span key={i} className="px-2 py-1 rounded bg-background border border-border text-xs font-medium">{t}</span>
              ))}
              {report.weakTopics.length === 0 && <span className="text-muted-foreground text-sm">None identified</span>}
            </div>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="bg-card rounded-2xl p-6 border border-border shadow-lg">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
              <MessageSquare className="w-5 h-5 text-primary" />
            </div>
            <h3 className="text-sm font-medium text-muted-foreground mb-2">Communication</h3>
            <p className="text-sm text-foreground leading-relaxed">{report.communicationFeedback}</p>
          </motion.div>
        </div>

        {/* Overall Feedback */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="bg-gradient-to-br from-primary/10 to-transparent border border-primary/20 rounded-2xl p-6 md:p-8">
          <h2 className="flex items-center gap-2 text-xl font-display font-bold text-foreground mb-4">
            <TrendingUp className="w-6 h-6 text-primary" /> Overall Assessment
          </h2>
          <p className="text-muted-foreground leading-relaxed text-lg">
            {report.overallFeedback}
          </p>
        </motion.div>

        {/* Detailed Q&A Breakdown */}
        <div className="space-y-6 pt-8">
          <h2 className="text-2xl font-display font-bold text-foreground">Detailed Breakdown</h2>
          
          <div className="space-y-4">
            {report.answers.map((answer, index) => (
              <motion.div 
                key={answer.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.5 + (index * 0.1) }}
                className="bg-card rounded-2xl border border-border overflow-hidden group"
              >
                <div className="p-6 sm:p-8">
                  <div className="flex flex-col md:flex-row gap-6">
                    <div className="shrink-0 flex flex-col items-center">
                      <div className={cn("w-16 h-16 rounded-full border-4 flex items-center justify-center shadow-lg", 
                        answer.score >= 8 ? "border-success text-success bg-success/5" :
                        answer.score >= 6 ? "border-warning text-warning bg-warning/5" :
                        "border-destructive text-destructive bg-destructive/5"
                      )}>
                        <span className="text-2xl font-bold">{answer.score}</span>
                      </div>
                      <span className="text-xs text-muted-foreground mt-2 font-medium bg-background px-2 py-1 rounded-md border border-border">{answer.emotion}</span>
                    </div>

                    <div className="flex-1 space-y-4">
                      <div>
                        <span className="text-xs font-bold text-primary uppercase tracking-wider mb-1 block">Question {answer.questionIndex}</span>
                        <h3 className="text-lg font-semibold text-foreground leading-snug">{answer.question}</h3>
                      </div>
                      
                      <div className="bg-background rounded-xl p-4 border border-border/50">
                        <span className="text-xs font-semibold text-muted-foreground uppercase tracking-widest block mb-2">Your Answer</span>
                        <p className="text-sm text-foreground/80 italic">"{answer.transcribedText}"</p>
                      </div>

                      <div>
                        <span className="text-xs font-semibold text-muted-foreground uppercase tracking-widest block mb-2">AI Feedback</span>
                        <p className="text-sm text-foreground leading-relaxed">{answer.feedback}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Action Bottom */}
        <div className="flex justify-center pt-12 pb-8">
          <button
            onClick={() => setLocation("/")}
            className="group px-8 py-4 rounded-xl font-bold text-primary-foreground bg-primary shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/40 hover:-translate-y-0.5 transition-all flex items-center gap-3 text-lg"
          >
            Start Another Interview
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

      </main>
    </div>
  );
}
