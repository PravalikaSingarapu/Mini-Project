import { motion } from "framer-motion";
import { CheckCircle2, XCircle, Activity, Mic, Clock } from "lucide-react";
import type { AnswerAnalysis } from "@workspace/api-client-react";

interface FeedbackCardProps {
  analysis: AnswerAnalysis;
  onNext: () => void;
  isLastQuestion: boolean;
}

export function FeedbackCard({ analysis, onNext, isLastQuestion }: FeedbackCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-card border border-border rounded-2xl p-6 md:p-8 shadow-2xl w-full max-w-4xl mx-auto"
    >
      <div className="flex flex-col md:flex-row gap-8 items-start">
        {/* Score Ring */}
        <div className="flex flex-col items-center justify-center min-w-[160px] shrink-0">
          <div className="relative w-32 h-32 flex items-center justify-center rounded-full bg-background border-8 border-primary/20">
            <svg className="absolute inset-0 w-full h-full transform -rotate-90">
              <circle
                cx="64"
                cy="64"
                r="56"
                className="stroke-primary fill-none transition-all duration-1000 ease-out"
                strokeWidth="8"
                strokeLinecap="round"
                strokeDasharray={2 * Math.PI * 56}
                strokeDashoffset={2 * Math.PI * 56 * (1 - analysis.score / 10)}
              />
            </svg>
            <div className="flex flex-col items-center">
              <span className="text-4xl font-display font-bold text-foreground">{analysis.score}</span>
              <span className="text-xs text-muted-foreground">/ 10</span>
            </div>
          </div>
          <div className="mt-4 flex items-center gap-2 px-4 py-1.5 rounded-full bg-accent/10 border border-accent/20">
            <Activity className="w-4 h-4 text-accent" />
            <span className="text-sm font-medium text-accent">{analysis.emotion}</span>
          </div>
        </div>

        {/* Feedback Details */}
        <div className="flex-1 space-y-6">
          <div>
            <h3 className="text-xl font-display font-bold text-foreground mb-2">AI Feedback</h3>
            <p className="text-muted-foreground leading-relaxed">{analysis.feedback}</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-background rounded-xl p-4 border border-border">
              <h4 className="flex items-center gap-2 text-sm font-semibold text-success mb-3">
                <CheckCircle2 className="w-4 h-4" />
                Keywords Hit
              </h4>
              <div className="flex flex-wrap gap-2">
                {analysis.keywordsFound.map((kw, i) => (
                  <span key={i} className="px-2 py-1 rounded-md bg-success/10 text-success text-xs font-medium">
                    {kw}
                  </span>
                ))}
                {analysis.keywordsFound.length === 0 && (
                  <span className="text-xs text-muted-foreground">None found</span>
                )}
              </div>
            </div>

            <div className="bg-background rounded-xl p-4 border border-border">
              <h4 className="flex items-center gap-2 text-sm font-semibold text-destructive mb-3">
                <XCircle className="w-4 h-4" />
                Missed Concepts
              </h4>
              <div className="flex flex-wrap gap-2">
                {analysis.keywordsMissed.map((kw, i) => (
                  <span key={i} className="px-2 py-1 rounded-md bg-destructive/10 text-destructive text-xs font-medium">
                    {kw}
                  </span>
                ))}
                {analysis.keywordsMissed.length === 0 && (
                  <span className="text-xs text-muted-foreground">None missed!</span>
                )}
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground bg-background rounded-lg p-3 border border-border">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              <span>Time: <strong className="text-foreground">{analysis.timeTakenSeconds}s</strong></span>
            </div>
            <div className="flex items-center gap-2">
              <Mic className="w-4 h-4" />
              <span>Quality: <strong className="text-foreground">{analysis.speakingQuality}</strong></span>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-8 pt-6 border-t border-border flex justify-end">
        <button
          onClick={onNext}
          className="px-8 py-3 rounded-xl font-semibold bg-primary text-primary-foreground hover:bg-primary/90 transition-colors shadow-lg shadow-primary/20"
        >
          {isLastQuestion ? "View Final Report" : "Next Question"}
        </button>
      </div>
    </motion.div>
  );
}
