import { Router, type IRouter } from "express";
import multer from "multer";
import { db } from "@workspace/db";
import { interviewSessionsTable, interviewAnswersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { openai } from "@workspace/integrations-openai-ai-server";
import { JOB_ROLES, ROLE_QUESTIONS } from "./questions.js";
import { analyzeAnswer } from "./analyze.js";
import {
  CreateInterviewSessionBody,
  SubmitAnswerBody,
  TranscribeAudioBody,
  GenerateResumeQuestionsBody,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/roles", (_req, res) => {
  res.json(JOB_ROLES);
});

router.post("/sessions", async (req, res) => {
  try {
    const body = CreateInterviewSessionBody.parse(req.body);
    const role = JOB_ROLES.find(r => r.id === body.roleId);
    if (!role) {
      res.status(404).json({ error: "Role not found" });
      return;
    }

    let questions = ROLE_QUESTIONS[body.roleId] ?? [];

    if (body.resumeText && body.resumeText.trim().length > 0) {
      try {
        const prompt = `Based on this resume, generate 3 personalized interview questions for a ${role.name} position. Format as JSON array of objects with fields: question, topic, expectedKeywords (array of strings), timeLimitSeconds (60).

Resume:
${body.resumeText.substring(0, 2000)}

Respond with only a JSON array.`;

        const response = await openai.chat.completions.create({
          model: "gpt-5.2",
          max_completion_tokens: 1024,
          messages: [{ role: "user", content: prompt }],
        });

        const content = response.choices[0]?.message?.content ?? "";
        const jsonMatch = content.match(/\[[\s\S]*\]/);
        if (jsonMatch) {
          const resumeQuestions = JSON.parse(jsonMatch[0]);
          questions = [...resumeQuestions.slice(0, 3), ...questions.slice(0, 7)];
        }
      } catch (err) {
        console.error("Resume question gen error:", err);
      }
    }

    const [session] = await db.insert(interviewSessionsTable).values({
      roleId: body.roleId,
      roleName: role.name,
      status: "in_progress",
      currentQuestionIndex: 0,
      totalQuestions: questions.length,
      resumeText: body.resumeText ?? null,
      questions: questions as any,
    }).returning();

    res.status(201).json({
      id: session.id,
      roleId: session.roleId,
      roleName: session.roleName,
      status: session.status,
      currentQuestionIndex: session.currentQuestionIndex,
      totalQuestions: session.totalQuestions,
      createdAt: session.createdAt.toISOString(),
    });
  } catch (err) {
    console.error("Create session error:", err);
    res.status(400).json({ error: String(err) });
  }
});

router.get("/sessions/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const session = await db.query.interviewSessionsTable.findFirst({
      where: eq(interviewSessionsTable.id, id),
    });

    if (!session) {
      res.status(404).json({ error: "Session not found" });
      return;
    }

    const answers = await db.select().from(interviewAnswersTable)
      .where(eq(interviewAnswersTable.sessionId, id))
      .orderBy(interviewAnswersTable.questionIndex);

    res.json({
      id: session.id,
      roleId: session.roleId,
      roleName: session.roleName,
      status: session.status,
      currentQuestionIndex: session.currentQuestionIndex,
      totalQuestions: session.totalQuestions,
      createdAt: session.createdAt.toISOString(),
      answers: answers.map(a => ({
        id: a.id,
        questionIndex: a.questionIndex,
        question: a.question,
        transcribedText: a.transcribedText,
        score: a.score,
        feedback: a.feedback,
        suggestions: a.suggestions,
        keywordsFound: (a.keywordsFound as string[]) ?? [],
        keywordsMissed: (a.keywordsMissed as string[]) ?? [],
        emotion: a.emotion,
        speakingQuality: a.speakingQuality,
        timeTakenSeconds: a.timeTakenSeconds,
        completionStatus: a.completionStatus as "completed" | "timeout" | "partial",
      })),
    });
  } catch (err) {
    console.error("Get session error:", err);
    res.status(500).json({ error: String(err) });
  }
});

router.get("/sessions/:id/question", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const session = await db.query.interviewSessionsTable.findFirst({
      where: eq(interviewSessionsTable.id, id),
    });

    if (!session) {
      res.status(404).json({ error: "Session not found" });
      return;
    }

    const questions = (session.questions as any[]) ?? [];
    const idx = session.currentQuestionIndex;

    if (idx >= questions.length || session.status === "completed") {
      res.status(404).json({ error: "Interview completed" });
      return;
    }

    const q = questions[idx];
    res.json({
      questionIndex: idx,
      totalQuestions: questions.length,
      question: q.question,
      topic: q.topic,
      expectedKeywords: q.expectedKeywords ?? [],
      timeLimitSeconds: q.timeLimitSeconds ?? 60,
    });
  } catch (err) {
    console.error("Get question error:", err);
    res.status(500).json({ error: String(err) });
  }
});

router.post("/sessions/:id/answers", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const body = SubmitAnswerBody.parse(req.body);

    const session = await db.query.interviewSessionsTable.findFirst({
      where: eq(interviewSessionsTable.id, id),
    });

    if (!session) {
      res.status(404).json({ error: "Session not found" });
      return;
    }

    const questions = (session.questions as any[]) ?? [];
    const q = questions[body.questionIndex];
    const expectedKeywords = q?.expectedKeywords ?? [];
    const timeLimitSeconds = q?.timeLimitSeconds ?? 60;

    const completionStatus = body.timeTakenSeconds >= timeLimitSeconds ? "timeout" : "completed";

    const analysis = await analyzeAnswer(
      body.question,
      body.transcribedText,
      expectedKeywords,
      body.timeTakenSeconds,
      timeLimitSeconds
    );

    const [answer] = await db.insert(interviewAnswersTable).values({
      sessionId: id,
      questionIndex: body.questionIndex,
      question: body.question,
      transcribedText: body.transcribedText,
      score: analysis.score,
      feedback: analysis.feedback,
      suggestions: analysis.suggestions,
      keywordsFound: analysis.keywordsFound as any,
      keywordsMissed: analysis.keywordsMissed as any,
      emotion: analysis.emotion,
      speakingQuality: analysis.speakingQuality,
      timeTakenSeconds: body.timeTakenSeconds,
      completionStatus,
    }).returning();

    const nextQuestionIndex = body.questionIndex + 1;
    const isComplete = nextQuestionIndex >= questions.length;

    await db.update(interviewSessionsTable)
      .set({
        currentQuestionIndex: nextQuestionIndex,
        status: isComplete ? "completed" : "in_progress",
      })
      .where(eq(interviewSessionsTable.id, id));

    res.status(201).json({
      id: answer.id,
      questionIndex: answer.questionIndex,
      question: answer.question,
      transcribedText: answer.transcribedText,
      score: answer.score,
      feedback: answer.feedback,
      suggestions: answer.suggestions,
      keywordsFound: (answer.keywordsFound as string[]) ?? [],
      keywordsMissed: (answer.keywordsMissed as string[]) ?? [],
      emotion: answer.emotion,
      speakingQuality: answer.speakingQuality,
      timeTakenSeconds: answer.timeTakenSeconds,
      completionStatus: answer.completionStatus as "completed" | "timeout" | "partial",
    });
  } catch (err) {
    console.error("Submit answer error:", err);
    res.status(500).json({ error: String(err) });
  }
});

router.get("/sessions/:id/report", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const session = await db.query.interviewSessionsTable.findFirst({
      where: eq(interviewSessionsTable.id, id),
    });

    if (!session) {
      res.status(404).json({ error: "Session not found" });
      return;
    }

    const answers = await db.select().from(interviewAnswersTable)
      .where(eq(interviewAnswersTable.sessionId, id))
      .orderBy(interviewAnswersTable.questionIndex);

    const avgScore = answers.length > 0
      ? answers.reduce((sum, a) => sum + a.score, 0) / answers.length
      : 0;

    const sortedByScore = [...answers].sort((a, b) => b.score - a.score);
    const strongTopics = sortedByScore.slice(0, 3).map(a => {
      const questions = (session.questions as any[]) ?? [];
      return questions[a.questionIndex]?.topic ?? `Question ${a.questionIndex + 1}`;
    });
    const weakTopics = sortedByScore.slice(-3).reverse().map(a => {
      const questions = (session.questions as any[]) ?? [];
      return questions[a.questionIndex]?.topic ?? `Question ${a.questionIndex + 1}`;
    });

    const avgWords = answers.length > 0
      ? answers.reduce((sum, a) => sum + a.transcribedText.split(/\s+/).length, 0) / answers.length
      : 0;

    const emotions = answers.map(a => a.emotion);
    const confidentCount = emotions.filter(e => e === "Confident" || e === "Enthusiastic").length;
    const nervousCount = emotions.filter(e => e === "Nervous").length;

    let communicationFeedback = "Your communication is clear and effective.";
    if (nervousCount > answers.length / 2) {
      communicationFeedback = "Try to speak more confidently. Reduce filler words like 'um' and 'uh'.";
    } else if (confidentCount > answers.length / 2) {
      communicationFeedback = "Excellent communication! You spoke confidently and clearly.";
    } else if (avgWords < 30) {
      communicationFeedback = "Try to elaborate more in your answers. Provide detailed explanations.";
    }

    let overallFeedback = `You completed ${answers.length} out of ${session.totalQuestions} questions with an average score of ${avgScore.toFixed(1)}/10. `;
    if (avgScore >= 8) overallFeedback += "Outstanding performance! You demonstrated strong knowledge.";
    else if (avgScore >= 6) overallFeedback += "Good effort! With more practice, you can improve significantly.";
    else overallFeedback += "Keep practicing! Focus on the weak areas and review the key concepts.";

    res.json({
      sessionId: session.id,
      roleName: session.roleName,
      totalQuestions: session.totalQuestions,
      answeredQuestions: answers.length,
      averageScore: Math.round(avgScore * 10) / 10,
      strongTopics: [...new Set(strongTopics)],
      weakTopics: [...new Set(weakTopics)],
      communicationFeedback,
      overallFeedback,
      answers: answers.map(a => ({
        id: a.id,
        questionIndex: a.questionIndex,
        question: a.question,
        transcribedText: a.transcribedText,
        score: a.score,
        feedback: a.feedback,
        suggestions: a.suggestions,
        keywordsFound: (a.keywordsFound as string[]) ?? [],
        keywordsMissed: (a.keywordsMissed as string[]) ?? [],
        emotion: a.emotion,
        speakingQuality: a.speakingQuality,
        timeTakenSeconds: a.timeTakenSeconds,
        completionStatus: a.completionStatus as "completed" | "timeout" | "partial",
      })),
    });
  } catch (err) {
    console.error("Get report error:", err);
    res.status(500).json({ error: String(err) });
  }
});

router.post("/transcribe", async (req, res) => {
  try {
    const body = TranscribeAudioBody.parse(req.body);
    const audioBuffer = Buffer.from(body.audioBase64, "base64");

    const { speechToText } = await import("@workspace/integrations-openai-ai-server/audio");
    const text = await speechToText(audioBuffer, "webm");
    res.json({ text });
  } catch (err) {
    console.error("Transcribe error:", err);
    res.status(500).json({ error: String(err) });
  }
});

router.post("/resume-questions", async (req, res) => {
  try {
    const body = GenerateResumeQuestionsBody.parse(req.body);
    const role = JOB_ROLES.find(r => r.id === body.roleId);

    const prompt = `Based on this resume, generate 5 personalized interview questions for a ${role?.name ?? body.roleId} position. Focus on the candidate's specific experience and skills.

Resume:
${body.resumeText.substring(0, 2000)}

Respond with only a JSON array of question strings.`;

    const response = await openai.chat.completions.create({
      model: "gpt-5.2",
      max_completion_tokens: 1024,
      messages: [{ role: "user", content: prompt }],
    });

    const content = response.choices[0]?.message?.content ?? "";
    const jsonMatch = content.match(/\[[\s\S]*\]/);
    let questions: string[] = [];
    if (jsonMatch) {
      questions = JSON.parse(jsonMatch[0]);
    }

    res.json({ questions });
  } catch (err) {
    console.error("Resume questions error:", err);
    res.status(500).json({ error: String(err) });
  }
});

export default router;
