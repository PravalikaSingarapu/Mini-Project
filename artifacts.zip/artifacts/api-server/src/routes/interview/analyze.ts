import { openai } from "@workspace/integrations-openai-ai-server";

export type AnalysisResult = {
  score: number;
  feedback: string;
  suggestions: string;
  keywordsFound: string[];
  keywordsMissed: string[];
  emotion: string;
  speakingQuality: string;
};

function detectEmotionFromText(text: string): { emotion: string; speakingQuality: string } {
  const lowerText = text.toLowerCase();
  const wordCount = text.split(/\s+/).filter(Boolean).length;

  const confidentWords = ["definitely", "certainly", "clearly", "absolutely", "confident", "sure", "know", "understand", "experience", "worked", "implemented", "built", "designed"];
  const nervousWords = ["um", "uh", "like", "maybe", "sort of", "kind of", "i think", "not sure", "hmm", "basically", "actually", "i guess"];

  const confidentCount = confidentWords.filter(w => lowerText.includes(w)).length;
  const nervousCount = nervousWords.filter(w => lowerText.includes(w)).length;

  let emotion = "Calm";
  if (confidentCount >= 3) emotion = "Confident";
  else if (nervousCount >= 3) emotion = "Nervous";
  else if (confidentCount >= 2) emotion = "Enthusiastic";

  let speakingQuality = "Average";
  if (wordCount > 100) speakingQuality = "Excellent";
  else if (wordCount > 60) speakingQuality = "Good";
  else if (wordCount < 20) speakingQuality = "Needs Improvement";

  return { emotion, speakingQuality };
}

export async function analyzeAnswer(
  question: string,
  transcribedText: string,
  expectedKeywords: string[],
  timeTakenSeconds: number,
  timeLimitSeconds: number
): Promise<AnalysisResult> {
  const foundKeywords = expectedKeywords.filter(kw =>
    transcribedText.toLowerCase().includes(kw.toLowerCase())
  );
  const missedKeywords = expectedKeywords.filter(kw =>
    !transcribedText.toLowerCase().includes(kw.toLowerCase())
  );

  const keywordScore = expectedKeywords.length > 0
    ? (foundKeywords.length / expectedKeywords.length) * 10
    : 5;

  const { emotion, speakingQuality } = detectEmotionFromText(transcribedText);

  const prompt = `You are an expert technical interviewer. Analyze the following interview answer and provide constructive feedback.

Question: ${question}

Candidate's Answer: "${transcribedText}"

Expected Keywords/Concepts: ${expectedKeywords.join(", ")}
Keywords Found: ${foundKeywords.join(", ") || "None"}
Keywords Missed: ${missedKeywords.join(", ") || "None"}
Time taken: ${timeTakenSeconds} seconds (limit: ${timeLimitSeconds} seconds)

Please analyze the answer and respond in the following JSON format:
{
  "score": <number from 1-10>,
  "feedback": "<2-3 sentences of direct feedback about what was good and what was missing>",
  "suggestions": "<1-2 specific suggestions for improvement>"
}

Be concise, specific, and constructive. Score based on: accuracy, completeness, keyword coverage, and clarity.`;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5.2",
      max_completion_tokens: 512,
      messages: [{ role: "user", content: prompt }],
    });

    const content = response.choices[0]?.message?.content ?? "";
    const jsonMatch = content.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      return {
        score: Math.min(10, Math.max(1, parsed.score ?? keywordScore)),
        feedback: parsed.feedback ?? "Answer analyzed.",
        suggestions: parsed.suggestions ?? "Practice more to improve your answers.",
        keywordsFound: foundKeywords,
        keywordsMissed: missedKeywords,
        emotion,
        speakingQuality,
      };
    }
  } catch (err) {
    console.error("AI analysis error:", err);
  }

  return {
    score: Math.round(keywordScore * 10) / 10,
    feedback: foundKeywords.length > 0
      ? `Good mention of: ${foundKeywords.slice(0, 3).join(", ")}.`
      : "Your answer could be more detailed and cover key concepts.",
    suggestions: missedKeywords.length > 0
      ? `Consider covering: ${missedKeywords.slice(0, 3).join(", ")}.`
      : "Great answer! Try to give more real-world examples next time.",
    keywordsFound: foundKeywords,
    keywordsMissed: missedKeywords,
    emotion,
    speakingQuality,
  };
}
