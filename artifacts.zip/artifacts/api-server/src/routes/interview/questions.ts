type Question = {
  question: string;
  topic: string;
  expectedKeywords: string[];
  timeLimitSeconds: number;
};

type JobRoleQuestions = {
  [roleId: string]: Question[];
};

export const JOB_ROLES = [
  {
    id: "data_scientist",
    name: "Data Scientist",
    description: "Machine learning, statistics, and data analysis",
    questionCount: 10,
  },
  {
    id: "python_developer",
    name: "Python Developer",
    description: "Python programming, frameworks, and best practices",
    questionCount: 10,
  },
  {
    id: "full_stack_engineer",
    name: "Full Stack Engineer",
    description: "Frontend, backend, databases, and system design",
    questionCount: 10,
  },
  {
    id: "ml_engineer",
    name: "ML Engineer",
    description: "Machine learning engineering, MLOps, and deployment",
    questionCount: 10,
  },
  {
    id: "devops_engineer",
    name: "DevOps Engineer",
    description: "CI/CD, containerization, cloud, and infrastructure",
    questionCount: 10,
  },
];

export const ROLE_QUESTIONS: JobRoleQuestions = {
  data_scientist: [
    {
      question: "Explain what Machine Learning is and how it differs from traditional programming.",
      topic: "Machine Learning Basics",
      expectedKeywords: ["data", "model", "training", "patterns", "algorithms", "predictions", "features", "labeled"],
      timeLimitSeconds: 60,
    },
    {
      question: "What is the difference between supervised and unsupervised learning? Give examples of each.",
      topic: "ML Categories",
      expectedKeywords: ["supervised", "unsupervised", "labels", "classification", "regression", "clustering", "k-means", "SVM"],
      timeLimitSeconds: 60,
    },
    {
      question: "What is overfitting and how do you prevent it?",
      topic: "Model Optimization",
      expectedKeywords: ["overfitting", "regularization", "cross-validation", "dropout", "pruning", "training data", "generalize", "L1", "L2"],
      timeLimitSeconds: 60,
    },
    {
      question: "Explain the bias-variance tradeoff in machine learning.",
      topic: "Model Theory",
      expectedKeywords: ["bias", "variance", "tradeoff", "underfitting", "overfitting", "error", "complexity", "simple", "complex"],
      timeLimitSeconds: 60,
    },
    {
      question: "What is a confusion matrix and how do you interpret it?",
      topic: "Model Evaluation",
      expectedKeywords: ["confusion matrix", "precision", "recall", "accuracy", "true positive", "false positive", "F1", "classification"],
      timeLimitSeconds: 60,
    },
    {
      question: "What is the difference between bagging and boosting? Give examples of algorithms.",
      topic: "Ensemble Methods",
      expectedKeywords: ["bagging", "boosting", "random forest", "XGBoost", "AdaBoost", "ensemble", "parallel", "sequential"],
      timeLimitSeconds: 60,
    },
    {
      question: "Explain what cross-validation is and why it is important.",
      topic: "Validation Techniques",
      expectedKeywords: ["cross-validation", "k-fold", "train", "test", "validation", "generalization", "split", "overfitting"],
      timeLimitSeconds: 60,
    },
    {
      question: "What is deep learning and how does it relate to neural networks?",
      topic: "Deep Learning",
      expectedKeywords: ["deep learning", "neural network", "layers", "neurons", "activation", "backpropagation", "weights", "hidden layers"],
      timeLimitSeconds: 60,
    },
    {
      question: "Explain the concept of feature engineering and why it matters.",
      topic: "Feature Engineering",
      expectedKeywords: ["feature engineering", "features", "transformation", "normalization", "encoding", "selection", "dimensionality", "PCA"],
      timeLimitSeconds: 60,
    },
    {
      question: "How would you handle missing data in a dataset?",
      topic: "Data Preprocessing",
      expectedKeywords: ["missing data", "imputation", "mean", "median", "mode", "drop", "fill", "KNN", "interpolation"],
      timeLimitSeconds: 60,
    },
  ],
  python_developer: [
    {
      question: "What are Python decorators and how do you use them?",
      topic: "Python Advanced",
      expectedKeywords: ["decorator", "function", "wrapper", "@ symbol", "closure", "higher-order", "functools", "class decorator"],
      timeLimitSeconds: 60,
    },
    {
      question: "Explain the difference between lists, tuples, and sets in Python.",
      topic: "Python Data Structures",
      expectedKeywords: ["list", "tuple", "set", "mutable", "immutable", "ordered", "unordered", "duplicates", "indexing"],
      timeLimitSeconds: 60,
    },
    {
      question: "What is a Python generator and when would you use one?",
      topic: "Python Generators",
      expectedKeywords: ["generator", "yield", "iterator", "lazy evaluation", "memory", "next()", "for loop", "infinite sequence"],
      timeLimitSeconds: 60,
    },
    {
      question: "Explain Python's GIL (Global Interpreter Lock) and its implications.",
      topic: "Python Internals",
      expectedKeywords: ["GIL", "Global Interpreter Lock", "threading", "multiprocessing", "CPU-bound", "I/O-bound", "concurrency", "CPython"],
      timeLimitSeconds: 60,
    },
    {
      question: "What are Python context managers and how do you implement one?",
      topic: "Python Context Managers",
      expectedKeywords: ["context manager", "with statement", "__enter__", "__exit__", "contextlib", "resource management", "file handling"],
      timeLimitSeconds: 60,
    },
    {
      question: "What is the difference between shallow copy and deep copy in Python?",
      topic: "Python Memory",
      expectedKeywords: ["shallow copy", "deep copy", "copy module", "reference", "nested objects", "mutable", "id()", "clone"],
      timeLimitSeconds: 60,
    },
    {
      question: "Explain Python's memory management and garbage collection.",
      topic: "Python Memory Management",
      expectedKeywords: ["garbage collection", "reference counting", "cyclic garbage collector", "memory", "del", "gc module", "heap", "stack"],
      timeLimitSeconds: 60,
    },
    {
      question: "What are Python metaclasses and when would you use them?",
      topic: "Python OOP",
      expectedKeywords: ["metaclass", "type", "class creation", "OOP", "__new__", "__init__", "inheritance", "singleton"],
      timeLimitSeconds: 60,
    },
    {
      question: "How does Python handle exceptions? Explain try, except, else, and finally.",
      topic: "Error Handling",
      expectedKeywords: ["try", "except", "finally", "else", "exception", "error handling", "raise", "custom exception", "BaseException"],
      timeLimitSeconds: 60,
    },
    {
      question: "What are Python comprehensions? Explain list, dict, and set comprehensions.",
      topic: "Python Comprehensions",
      expectedKeywords: ["list comprehension", "dict comprehension", "set comprehension", "generator expression", "conditional", "loop", "readable", "performance"],
      timeLimitSeconds: 60,
    },
  ],
  full_stack_engineer: [
    {
      question: "Explain the difference between REST and GraphQL APIs.",
      topic: "API Design",
      expectedKeywords: ["REST", "GraphQL", "endpoints", "schema", "query", "mutation", "over-fetching", "under-fetching", "HTTP"],
      timeLimitSeconds: 60,
    },
    {
      question: "What is the difference between SQL and NoSQL databases? When would you use each?",
      topic: "Databases",
      expectedKeywords: ["SQL", "NoSQL", "relational", "document", "key-value", "schema", "ACID", "scalability", "MongoDB", "PostgreSQL"],
      timeLimitSeconds: 60,
    },
    {
      question: "Explain how React's virtual DOM works and why it improves performance.",
      topic: "Frontend",
      expectedKeywords: ["virtual DOM", "reconciliation", "diff", "rendering", "component", "state", "props", "re-render", "optimization"],
      timeLimitSeconds: 60,
    },
    {
      question: "What is server-side rendering (SSR) and when would you use it over client-side rendering?",
      topic: "Rendering Strategies",
      expectedKeywords: ["SSR", "CSR", "SEO", "performance", "initial load", "hydration", "Next.js", "static generation", "ISR"],
      timeLimitSeconds: 60,
    },
    {
      question: "Explain authentication vs authorization. How would you implement JWT-based auth?",
      topic: "Security",
      expectedKeywords: ["authentication", "authorization", "JWT", "token", "claims", "refresh token", "middleware", "OAuth", "session"],
      timeLimitSeconds: 60,
    },
    {
      question: "What is microservices architecture? What are the pros and cons compared to monolith?",
      topic: "System Design",
      expectedKeywords: ["microservices", "monolith", "service", "scalability", "independent deployment", "communication", "complexity", "API gateway"],
      timeLimitSeconds: 60,
    },
    {
      question: "How would you optimize a slow database query?",
      topic: "Database Optimization",
      expectedKeywords: ["indexing", "query optimization", "EXPLAIN", "N+1", "joins", "caching", "pagination", "denormalization", "partitioning"],
      timeLimitSeconds: 60,
    },
    {
      question: "What is CORS and how do you handle it in a web application?",
      topic: "Web Security",
      expectedKeywords: ["CORS", "cross-origin", "headers", "preflight", "Access-Control-Allow-Origin", "same-origin", "credentials", "OPTIONS"],
      timeLimitSeconds: 60,
    },
    {
      question: "Explain the concept of caching. What are the different types and when would you use each?",
      topic: "Caching",
      expectedKeywords: ["caching", "Redis", "CDN", "browser cache", "cache-control", "TTL", "invalidation", "memory cache", "distributed"],
      timeLimitSeconds: 60,
    },
    {
      question: "What are WebSockets and when would you use them over HTTP polling?",
      topic: "Real-time Communication",
      expectedKeywords: ["WebSockets", "real-time", "bidirectional", "polling", "long-polling", "SSE", "connection", "latency", "event"],
      timeLimitSeconds: 60,
    },
  ],
  ml_engineer: [
    {
      question: "Explain the ML model lifecycle from development to production.",
      topic: "MLOps",
      expectedKeywords: ["data collection", "training", "evaluation", "deployment", "monitoring", "retraining", "versioning", "CI/CD", "pipeline"],
      timeLimitSeconds: 60,
    },
    {
      question: "What is model drift and how do you detect and address it?",
      topic: "Model Monitoring",
      expectedKeywords: ["model drift", "data drift", "concept drift", "monitoring", "metrics", "alerts", "retraining", "KL divergence", "distribution shift"],
      timeLimitSeconds: 60,
    },
    {
      question: "How would you design a feature store for a machine learning system?",
      topic: "Feature Engineering at Scale",
      expectedKeywords: ["feature store", "features", "online", "offline", "serving", "Feast", "Tecton", "consistency", "reusability"],
      timeLimitSeconds: 60,
    },
    {
      question: "Explain A/B testing in the context of ML model deployment.",
      topic: "Experiment Design",
      expectedKeywords: ["A/B testing", "shadow deployment", "canary", "control group", "treatment group", "statistical significance", "metrics", "rollout"],
      timeLimitSeconds: 60,
    },
    {
      question: "What is model quantization and why would you use it?",
      topic: "Model Optimization",
      expectedKeywords: ["quantization", "int8", "fp16", "compression", "inference", "latency", "size", "accuracy tradeoff", "edge deployment"],
      timeLimitSeconds: 60,
    },
    {
      question: "How do you handle class imbalance in a classification problem?",
      topic: "Data Challenges",
      expectedKeywords: ["class imbalance", "oversampling", "undersampling", "SMOTE", "class weights", "precision-recall", "F1", "AUC-ROC"],
      timeLimitSeconds: 60,
    },
    {
      question: "Explain transfer learning and when you would use it.",
      topic: "Advanced ML",
      expectedKeywords: ["transfer learning", "pre-trained", "fine-tuning", "domain adaptation", "ImageNet", "BERT", "frozen layers", "few-shot"],
      timeLimitSeconds: 60,
    },
    {
      question: "What is the difference between batch inference and online inference?",
      topic: "Model Serving",
      expectedKeywords: ["batch inference", "online inference", "real-time", "latency", "throughput", "scheduled", "streaming", "SLA"],
      timeLimitSeconds: 60,
    },
    {
      question: "How would you containerize and serve an ML model at scale?",
      topic: "Deployment",
      expectedKeywords: ["Docker", "Kubernetes", "API", "REST", "load balancing", "auto-scaling", "TensorFlow Serving", "Torchserve", "FastAPI"],
      timeLimitSeconds: 60,
    },
    {
      question: "Explain explainability in ML. What tools and techniques do you know?",
      topic: "ML Interpretability",
      expectedKeywords: ["explainability", "SHAP", "LIME", "feature importance", "interpretable", "black box", "XAI", "attention", "saliency maps"],
      timeLimitSeconds: 60,
    },
  ],
  devops_engineer: [
    {
      question: "Explain the CI/CD pipeline. What tools would you use to set one up?",
      topic: "CI/CD",
      expectedKeywords: ["CI/CD", "continuous integration", "continuous deployment", "GitHub Actions", "Jenkins", "GitLab CI", "pipeline", "automation", "testing"],
      timeLimitSeconds: 60,
    },
    {
      question: "What is Infrastructure as Code (IaC)? Compare Terraform and Ansible.",
      topic: "Infrastructure as Code",
      expectedKeywords: ["infrastructure as code", "Terraform", "Ansible", "declarative", "imperative", "state", "provisioning", "configuration management"],
      timeLimitSeconds: 60,
    },
    {
      question: "Explain Docker containerization. What is the difference between a container and a VM?",
      topic: "Containerization",
      expectedKeywords: ["Docker", "container", "VM", "virtualization", "image", "isolation", "kernel", "overhead", "namespaces", "cgroups"],
      timeLimitSeconds: 60,
    },
    {
      question: "How does Kubernetes manage containerized applications? Explain key components.",
      topic: "Kubernetes",
      expectedKeywords: ["Kubernetes", "pod", "node", "cluster", "deployment", "service", "ingress", "scheduler", "etcd", "control plane"],
      timeLimitSeconds: 60,
    },
    {
      question: "What is blue-green deployment and how does it differ from canary releases?",
      topic: "Deployment Strategies",
      expectedKeywords: ["blue-green", "canary", "deployment", "traffic", "rollback", "zero downtime", "production", "testing in production"],
      timeLimitSeconds: 60,
    },
    {
      question: "Explain how you would monitor a production system. What metrics matter?",
      topic: "Monitoring",
      expectedKeywords: ["monitoring", "metrics", "Prometheus", "Grafana", "alerts", "SLO", "SLA", "latency", "throughput", "error rate"],
      timeLimitSeconds: 60,
    },
    {
      question: "What is a load balancer and what are the different load balancing algorithms?",
      topic: "Load Balancing",
      expectedKeywords: ["load balancer", "round robin", "least connections", "weighted", "health check", "sticky sessions", "L4", "L7", "nginx"],
      timeLimitSeconds: 60,
    },
    {
      question: "How would you secure a cloud infrastructure? What practices do you follow?",
      topic: "Security",
      expectedKeywords: ["IAM", "least privilege", "security groups", "VPC", "encryption", "secrets management", "audit logs", "MFA", "network policy"],
      timeLimitSeconds: 60,
    },
    {
      question: "Explain the difference between horizontal and vertical scaling.",
      topic: "Scalability",
      expectedKeywords: ["horizontal scaling", "vertical scaling", "scale out", "scale up", "load balancer", "auto-scaling", "stateless", "cost"],
      timeLimitSeconds: 60,
    },
    {
      question: "What is a service mesh and when would you use one?",
      topic: "Service Mesh",
      expectedKeywords: ["service mesh", "Istio", "Linkerd", "sidecar", "traffic management", "observability", "mTLS", "circuit breaker", "retries"],
      timeLimitSeconds: 60,
    },
  ],
};
